@extends('layouts.app_fe')



@section('content')
	<div class="row">
	<div class="col-xl-3 col-lg-4 col-md-12 theiaStickySidebar">
		<?= view('layouts.app_side'); ?>
	</div>
	<div class="col-xl-9 col-lg-8 col-md-12">

<style>
    .trr {
        background-color: #0099FF;
        color: #ffffff;
        align: center;
        padding: 10px;
        height: 20px;
    }

    tr.odd>td {
        background-color: #E3F2FD;
    }

    tr.even>td {
        background-color: #BBDEFB;
    }

    .fixedTable .table {
        background-color: white;
        width: auto;
        display: table;
    }

    .fixedTable .table tr td,
    .fixedTable .table tr th {
        min-width: 100px;
        width: 100px;
        min-height: 20px;
        height: 20px;
        padding: 5px;
        max-width: 100px;
    }

    .fixedTable-header {
        width: 100%;
        height: 60px;
        /*margin-left: 150px;*/
        overflow: hidden;
        border-bottom: 1px solid #CCC;
    }

    .fixedTable-sidebar {
        width: 0;
        height: 510px;
        float: left;
        overflow: hidden;
        border-right: 1px solid #CCC;
    }

    @media screen and (max-height: 700px) {
        .fixedTable-body {
            overflow: auto;
            width: 100%;
            height: 410px;
            float: left;
        }
    }

    @media screen and (min-height: 700px) {
        .fixedTable-body {
            overflow: auto;
            width: 100%;
            height: 510px;
            float: left;
        }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    @include('flash-message')
    
    <!-- Content Header (Page header) -->
            <form action="<?= route('fe.lihat_slip'); ?>" method="get" id="slipGAJI" enctype="multipart/form-data">
    @csrf
    <div class="card shadow-sm ctm-border-radius">
        <div class="card-body align-center">
            <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label>Periode Tahun</label>
                    <select class="form-control " name="tahun" style="width: 100%;" required>
                    	<option value=""> - Periode Tahun -</option>
                    	<?php for($i=2022;$i<=date('Y');$i++){
                    				$selected = '';
                    			if($request->get('tahun')==$i){
                    				$selected = 'selected';
                    			}
                    			echo '<option value="'.$i.'" '.$selected.'>'.$i.'</option>';
                    	}?>	
                    </select>
                </div>
                </div>
                <div class="col-sm-3">
                            <div class="form-group">
                                <label>Bulan</label>
                                <select class="form-control select2" name="bulan" style="width: 100%;" required id="bulan"	>
                                    <option value="">Pilih</option>
                                    <option value="1" <?=$request->bulan==1?'selected':'';?>>Januari</option>
                                    <option value="2" <?=$request->bulan==2?'selected':'';?>>Februari</option>
                                    <option value="3" <?=$request->bulan==3?'selected':'';?>>Maret</option>
                                    <option value="4" <?=$request->bulan==4?'selected':'';?>>April</option>
                                    <option value="5" <?=$request->bulan==5?'selected':'';?>>Mei</option>
                                    <option value="6" <?=$request->bulan==6?'selected':'';?>>Juni</option>
                                    <option value="7" <?=$request->bulan==7?'selected':'';?>>Juli</option>
                                    <option value="8" <?=$request->bulan==8?'selected':'';?>>Agustus</option>
                                    <option value="9" <?=$request->bulan==9?'selected':'';?>>September</option>
                                    <option value="10" <?=$request->bulan==10?'selected':'';?>>Oktober</option>
                                    <option value="11" <?=$request->bulan==11?'selected':'';?>>November</option>
                                    <option value="12" <?=$request->bulan==12?'selected':'';?>>Desember</option>
                                </select>
                            </div>
                        </div> 
                        
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Periode Gajian</label>
                                <select class="form-control " name="periode_gajian" id="periode_gajian" style="width: 100%;" required onclick="pekanan()"	>
                                    <option value="">- Pekanan -</option>
                                    <option value="0" <?=$idkar[0]->periode_gajian==0?'selected':'';?>>Pekanan</option>
                                    <option value="1" <?=$idkar[0]->periode_gajian==1?'selected':'';?>>Bulanan</option>
                                </select>
                               
                            </div>
                        </div>
                       
                        <div class="col-sm-3 " id="pekanan" style="display: none">
                            <div class="form-group">
                                <label>Pekanan Ke</label>
                                <select class="form-control " name="pekanan_ke" id="pekanan_ke" style="width: 100%;" required 	>
                                    <option value="">- Pekanan -</option>
                                    <option value="1" <?=$request->pekanan_ke==1?'selected':'';?>>Pekanan Ke 1</option>
                                    <option value="2" <?=$request->pekanan_ke==2?'selected':'';?>>Pekanan Ke 2</option>
                                </select>
                            </div>
                        </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
                    <script>
                    	pekanan();
                    	function pekanan(){
                    		
                    		var periode_gajian = $("#periode_gajian").val();
                    		if(periode_gajian == 0){
                    			$('#pekanan').show();
                    		}else{
                    			$('#pekanan').hide();
                    			
                    		}
                    	}
                    	
                    	
                    	
                    </script>
                </div>
                
                <div class="form-group">
                    <button type="button" onclick="pop_up()" name="Cari" class="btn btn-primary" value="Cari"><span class="fa fa-search"></span> Cari</button>

                </div>
        </div>
    </div>
    @if($id_prl==-99)
	<div class="card">
	<div class="card-body text-center">
		<h2>Data gaji belum ada.</h2>
	</div>
	</div>
    @elseif(!empty($generate))
    <div class="card shadow-sm ctm-border-radius">
        <div class="card-body align-center">
            <h4 class="card-title float-left mb-0 mt-2">Slip Gaji</h4>
            <ul class="nav nav-tabs float-right border-0 tab-list-emp">

                <li class="nav-item pl-3">
                    <a href="{!! route('fe.tambah_chat',['','key=Klarifikasi Gaji Bulan '.$help->bulan($generate[0]->bulan).' '.($generate[0]->tahun)]) !!}" class="btn btn-theme button-1 text-white ctm-border-radius p-2 add-person ctm-btn-padding">Klarifikasi Gaji</a>
                    <button type="button" onclick="pdf()" name="Cari"  name="Cari" class="btn  btn-theme button-1 "value="PDF"><span class="fa fa-search"></span> PDF</button>
                    <!-- 
				<a href="{!! route('fe.lihat_slip',[$id_prl,'Cari=PDF']) !!}" class="btn btn-theme button-1 text-white ctm-border-radius p-2 add-person ctm-btn-padding">PDF</a>-->
                </li>
            </ul>

        </div>
    </div>
    
    

    <div class="content container-fluid">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2">
                                <?php
                                if ($gaji[0]->lokasi_id == 3) {
                                    $logo = 'Logo Rea Arta Mulia.png';
                                } else if ($gaji[0]->lokasi_id == 4) {
                                    $logo = 'Logo EMM_Page12.png';
                                } else if ($gaji[0]->lokasi_id == 5) {
                                    $logo = 'cc.png';
                                } else if ($gaji[0]->lokasi_id == 2) {
                                    $logo = 'Logo SJP Guideline.png';
                                } else  if ($gaji[0]->lokasi_id == 9) {
                                    $logo = 'Logo ASA.png';
                                } else if ($gaji[0]->lokasi_id == 13) {
                                    $logo = 'Logo Mafaza Hires.png';
                                } else if ($gaji[0]->lokasi_id == 6) {
                                    $logo = 'JKA LOGO.png';
                                } else
                                    $logo = 'logo.png';


                                ?>
                                <img src="<?= url('dist\img\logo/' . $logo); ?>" style="height:70px;margin-left:5%;vertical-align:middle" alt="">
                            </div>
                            <div class="col-sm-10 text-center">
                                <div style="margin-left: -20%">


                                    <h3><?= $gaji[0]->namalokasi; ?></h3>
                                    <div><?= $gaji[0]->alamat; ?></div>
                                </div>
                            </div>
                        </div>
                        <hr style="border-bottom:2px solid black">
                        <h4 class="payslip-title mb-0 text-center" style="font-size:20px;">Slip Gaji </h4>
                        <Div class="text-center">Gaji: <span><?= $help->bulan($generate[0]->bulan); ?>, <?= ($generate[0]->tahun); ?></span></Div>
                        <div class="row">
                            <div class="col-sm-6 m-b-20">
                                

                            </div>
                            <div class="col-sm-6 m-b-20">
                                <div class="invoice-details">

                                </div>
                            </div>
                            <div class="col-lg-12 m-b-20">
                                <ul class="list-unstyled">
                                    <li>
                                        <h4 class="mb-0"><strong><?= $karyawan[0]->nama_lengkap; ?></strong></h4>
                                    </li>
                                    <li><span><?= $gaji[0]->nmjabatan; ?> </span></li>
                                    <li>Departement <?= $karyawan[0]->nmdept; ?></li>
                                    <li><?= $gaji[0]->nmpangkat; ?></li>
                                    <li><?= $karyawan[0]->nama_grade; ?></li>
                                </ul>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div>
                                    <h4 class="m-b-10  pt-3 pb-3"><strong>Data Kerja</strong></h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                            <?php

                                            $sql = "select *
										from prl_gaji a 
										join prl_gaji_detail b on b.prl_gaji_id = a.prl_gaji_id 
										join m_gaji_absen on b.gaji_absen_id = m_gaji_absen.m_gaji_absen_id 
										where prl_generate_id = $id_prl and 
										p_karyawan_id = $id_kary  and 
										b.type=1 and b.active=1 and 
										m_gaji_absen.active =1
										order by prl_gaji_detail_id  desc
										";
                                            $row = DB::connection()->select($sql);
                                            $data = array();
                                            $sudah = array();
                                            $masuk = 0;
                                            foreach ($row as $row) {
                                                if (!in_array($row->m_gaji_absen_id, $sudah)) {
                                                    if ($row->nama_gaji == 'Hari Absen')
                                                        $masuk = round($row->nominal);
                                                    echo '<tr>
														<td>' . $row->nama_gaji . '</td>
														<td>' . round($row->nominal) . '</td>
													</tr>';
                                                    $sudah[] = $row->m_gaji_absen_id;
                                                }
                                            } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div>
                                    <h4 class="m-b-10 pt-3 pb-3"><strong>Pendapatan</strong></h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                            <?php

                                            $sql = "select *,case when type=1 then (select nama_gaji from m_gaji_absen where b.gaji_absen_id = m_gaji_absen.m_gaji_absen_id )
										when type=2 then (select nama from prl_tunjangan join m_tunjangan on prl_tunjangan.m_tunjangan_id = m_tunjangan.m_tunjangan_id where b.prl_tunjangan_id = prl_tunjangan.prl_tunjangan_id )
										when type=3 then (select nama from m_tunjangan where b.m_tunjangan_id = m_tunjangan.m_tunjangan_id)
										when type=4 then (select nama from prl_potongan join m_potongan on prl_potongan.m_potongan_id = m_potongan.m_potongan_id where b.prl_potongan_id = prl_potongan.prl_potongan_id )
										when type=5 then (select nama from m_potongan where b.m_potongan_id = m_potongan.m_potongan_id)
										end as nama
										from prl_gaji a 
										join prl_gaji_detail b on b.prl_gaji_id = a.prl_gaji_id 
											 	
										where prl_generate_id = $id_prl and 
										p_karyawan_id = $id_kary  and 
										b.type in (2,3)   and b.active=1
										order by prl_gaji_detail_id  desc,nominal desc
										";
                                            $row = DB::connection()->select($sql);
                                            $data = array();
                                            $total_tunjangan = 0;
                                            foreach ($row as $row) {
                                                if (!in_array($row->nama, $sudah)) {
                                                    if ($row->nama == 'Upah Harian') {
                                                        $row->nominal = $row->nominal * $masuk;
                                                    }
                                                   if($row->nama=='Tunjangan Entitas' and $row->nominal==0){
                                                        	
                                                        }else{
                                                        	
                                                        $total_tunjangan += $row->nominal;
                                                        echo '<tr>
															<td>' . $row->nama . '</td>
															<td>' . $help->rupiah2($row->nominal) . '<br>
																'.$row->keterangan.'
																
															</td>
														</tr>';
                                                        $sudah[] = $row->nama;
                                                        $data[$row->nama] = $row->nominal;
                                                        }	
                                                }
                                            }
                                            echo '<tr>
											<td><h5><b>TOTAL PENDAPATAN</b></h5></td>
											<td><h5><b>' . $help->rupiah2($total_tunjangan) . '</b></h5></td>
										</tr>'
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div>
                                    <h4 class="m-b-10  pt-3 pb-3"><strong>Potongan</strong></h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                            <?php

                                            $sql = "select *,case when type=1 then (select nama_gaji from m_gaji_absen where b.gaji_absen_id = m_gaji_absen.m_gaji_absen_id )
										when type=2 then (select nama from prl_tunjangan join m_tunjangan on prl_tunjangan.m_tunjangan_id = m_tunjangan.m_tunjangan_id where b.prl_tunjangan_id = prl_tunjangan.prl_tunjangan_id )
										when type=3 then (select nama from m_tunjangan where b.m_tunjangan_id = m_tunjangan.m_tunjangan_id)
										when type=4 then (select nama from prl_potongan join m_potongan on prl_potongan.m_potongan_id = m_potongan.m_potongan_id where b.prl_potongan_id = prl_potongan.prl_potongan_id )
										when type=5 then (select nama from m_potongan where b.m_potongan_id = m_potongan.m_potongan_id)
										end as nama
										from prl_gaji a 
										join prl_gaji_detail b on b.prl_gaji_id = a.prl_gaji_id 
											 	
										where prl_generate_id = $id_prl and 
										p_karyawan_id = $id_kary  and 
										b.type in (4,5)  and b.active=1
										order by prl_gaji_detail_id  desc,nominal desc
										";
                                            $row = DB::connection()->select($sql);
                                            $data = array();
                                            $total_potongan = 0;
                                            foreach ($row as $row) {
                                                if (!in_array($row->nama, $sudah)) {
                                                    $total_potongan += $row->nominal;
                                                    echo '<tr>
														<td>' . $row->nama . '</td>
														<td>' . $help->rupiah2($row->nominal, 0) . '<br>
														'.$row->keterangan.'
														</td>
													</tr>';
                                                    $sudah[] = $row->nama;
                                                }
                                            }
                                            echo '<tr>
											<td><h5><b>TOTAL POTONGAN</b></h5></td>
											<td><h5><b>' . $help->rupiah2($total_potongan) . '</b></h5></td>
										</tr>' ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <h4 class="mb-0 pb-0"><strong>TAKE HOME PAY: <?= $help->rupiah($total_tunjangan - $total_potongan) . '</b></strong></h4>' . $help->terbilang($total_tunjangan - $total_potongan) . ''; ?>
                    </div>

                </div>

                <!-- /Page Content -->
            </div>-->
        </div>
        <!-- /.card -->
        <!-- /.card -->
        <!-- /.content -->
    </div>
    
    @endif
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js">
    	<script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
    
    <textarea id="texttt" style="display: none">
    	Informasi yang ada di Slip Gaji ini bersifat RAHASIA..
    	<br>
    	<br>
    	Karyawan tidak diperkenanankan untuk menyebarluaskan informasi gaji karyawan kepada pihak lain tanpa persetujuan perusahaan.  
    	<br>
    	<br>
    	<br>
    	
    	
    	Hal ini sesuai dengan Ketentuan Perusahaan, karyawan yang melanggar dapat dikenakan sanksi sesuai Ketentuan Perusahaan.
    </textarea>
    <script>
        function pdf(){
        	
		$('#slipGAJI').append('<div><input type="hidden" name="Cari" value="PDF"/></div>');
		document.getElementById('slipGAJI').submit();
		}
        function pop_up(){
        	var txt =  "";
        	swal({
                        title: 'PERINGATAN!!!',
                        html:$("#texttt").val(),
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Ya, Mengerti !',
                        cancelButtonText: ' Batalkan!',
                        confirmButtonClass: 'btn btn-success',
                        cancelButtonClass: 'btn btn-danger',
                        buttonsStyling: false,
                        allowEnterKey: true,
                        reverseButtons: true
                    }).then((result) => {
                        if (result.value) {
                           
                            document.getElementById('slipGAJI').submit();
                        } else if (
                            // Read more about handling dismissals
                            result.dismiss === swal.DismissReason.cancel
                        ) {
                            swal(
                                'Cancelled',
                                'Anda Batal Melihat Slip Gaji.. :)',
                                'error'
                            )
                        }
                    })
        }
    </script>
    <!-- /.content-wrapper -->
    @endsection
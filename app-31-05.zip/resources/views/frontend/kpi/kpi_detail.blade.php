@extends('layouts.app_fe')

@section('content')
	<div class="row">
	<div class="col-xl-3 col-lg-4 col-md-12 theiaStickySidebar">
		<?= view('layouts.app_side'); ?>
	</div>
	<div class="col-xl-9 col-lg-8 col-md-12">

<!-- Content Wrapper. Contains page content -->
<div class="content">
    @include('flash-message')
    <!-- Content Header (Page header) -->
    <div class="card shadow-sm ctm-border-radius">
        <div class="card-body align-center">
            <h4 class="card-title float-left mb-0 mt-2">KPI Tahun <?=$kpi->tahun?></h4>
            <ul class="nav nav-tabs float-right border-0 tab-list-emp">

				<li class="nav-item pl-3">
					<a href="{!! route('fe.tambah_kpi_detail',$kpi->t_kpi_id) !!}" title='Tambah'  class="btn btn-theme button-1 text-white ctm-border-radius p-2 add-person ctm-btn-padding">Tambah Parameter Kerja</a>
				</li>
			</ul>

        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="card">
       
        <!-- /.card-header -->
        <div class="card-body">
           
           
			<Style>
				.table thead tr td{
					vertical-align:middle;
					text-align:center;
					font-size: 17px;
					font-weight: 700;
				}
			</Style>
			<div style="overflow-x:auto;">
            <table id="" class="table table-bordered table-striped" >
                <thead>
                    <tr>
                        <td rowspan="3">No.</td>
                        <td colspan="7">INDIKATOR KINERJA</td>
                        <td colspan="12">PENCAPAIAN KINERJA</td>
                        <td rowspan="3">Action</td>
                    </tr>
                    <tr>
                    
                        <td rowspan="2">AREA  KERJA</td>
                        <td colspan="2">SASARAN DAN PARAMETER</td>
                        <td></td>
                        <td></td>
                        <td>PRIORITAS</td>
                        <td>BOBOT</td>
                        <td colspan="3">TW 1  
                        @if($kpi->status_appr_2 ==1) <a href="{{ route('fe.edit_all_tw',[$kpi->t_kpi_id,1]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                        @endif
                        </td>
                        <td colspan="3">TW 2   @if($kpi->status_appr_2 ==1) <a href="{{ route('fe.edit_all_tw',[$kpi->t_kpi_id,2]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a> @endif</td>
                        <td colspan="3">TW 3  @if($kpi->status_appr_2 ==1)  <a href="{{ route('fe.edit_all_tw',[$kpi->t_kpi_id,3]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a> @endif</td>
                        <td colspan="3">TW 4   @if($kpi->status_appr_2 ==1) <a href="{{ route('fe.edit_all_tw',[$kpi->t_kpi_id,4]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a> @endif</td>
                    </tr>
                    <tr>
                        <td>SASARAN KERJA
</td>
                        <td>DEFINISI</td>
                        <td>TARGET</td>
                        <td>SATUAN</td>
                        <td>'1-3-5-7-9</td>
                        <td> (%)</td>
                        <td>Pencapaian</td>
                        <td>%Pencapaian</td>
                        <td>%Pencapaian x bobot</td>
                        
                        <td>Pencapaian</td>
                        <td>%Pencapaian</td>
                        <td>%Pencapaian x bobot</td>
                        
                        <td>Pencapaian</td>
                        <td>%Pencapaian</td>
                        <td>%Pencapaian x bobot</td>
                        
                        <td>Pencapaian</td>
                        <td>%Pencapaian</td>
                        <td>%Pencapaian x bobot</td>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 0 ?>
                    @if(!empty($kpi_detail))
                    <?php $total_tw1=0;;?>
                    <?php $total_tw2=0;?>
                    <?php $total_tw3=0;?>
                    <?php $total_tw4=0;?>
                    @foreach($kpi_detail as $kpi_detail)
                    <?php $no++ ?>
                   
                    <tr>
                        <td>{!! $no !!}</td>
                        <td>{!! $kpi_detail->nama_area_kerja !!}</td>
                        <td>{!! $kpi_detail->sasaran_kerja !!}</td>
                        <td>{!! $kpi_detail->definisi !!}</td>
                        <td>{!! $kpi_detail->target !!}</td>
                        <td>{!! $kpi_detail->satuan !!}</td>
                        <td>{!! $kpi_detail->prioritas !!}</td>
                        <td>{!! round($bobot = $kpi_detail->prioritas/$kpi_detail->sum*100,2) !!}%</td>
                        <td>{!! $kpi_detail->pencapaian_tw1 !!}   
                        @if($kpi_detail->approve_tw1==3 and $kpi->status_appr_2 ==1)
                        <a href="{{ route('fe.edit_tw',[$id,$kpi_detail->t_kpi_detail_id,1]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                        @endif
                        </td>
                        <td>{!! round($tw1 = $kpi_detail->pencapaian_tw1/$kpi_detail->target*100,2)  !!}%</td>
                        <td>{!! round($bobot1 =$tw1*$bobot/100,2)  !!}%</td>
                        <td>{!! $kpi_detail->pencapaian_tw2 !!}
                        @if($kpi_detail->approve_tw2==3  and $kpi->status_appr_2 ==1)
                        <a href="{{ route('fe.edit_tw',[$id,$kpi_detail->t_kpi_detail_id,2]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                        @endif</td>
                        <td>{!! round($tw2 = $kpi_detail->pencapaian_tw2/$kpi_detail->target*100,2)  !!}%</td>
                        <td>{!! round($bobot2 =$tw2*$bobot/100,2)  !!}%</td>
                        <td>{!! $kpi_detail->pencapaian_tw3 !!}
                        @if($kpi_detail->approve_tw3==3  and $kpi->status_appr_2 ==1)
                        <a href="{{ route('fe.edit_tw',[$id,$kpi_detail->t_kpi_detail_id,3]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                        @endif</td>
                        <td>{!! round($tw3 = $kpi_detail->pencapaian_tw3/$kpi_detail->target*100,2)  !!}%</td>
                        <td>{!! round($bobot3 = $tw3*$bobot/100,2)  !!}%</td>
                        <td>{!! $kpi_detail->pencapaian_tw4 !!}
                        @if($kpi_detail->approve_tw4==3  and $kpi->status_appr_2 ==1)
                        <a href="{{ route('fe.edit_tw',[$id,$kpi_detail->t_kpi_detail_id,4]) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>Edit</a>
                        @endif</td>
                        <td>{!! round($tw4 = $kpi_detail->pencapaian_tw4/$kpi_detail->target*100,2)  !!}%</td>
                        <td>{!! round($bobot4 = $tw4*$bobot/100,2)  !!}%</td>
                        <td>
                        	@if($kpi->status_appr_2 ==3)
                        	<div class="d-flex">
                        		
                        <a href="{{ route('fe.edit_kpi_detail',[$id,$kpi_detail->t_kpi_detail_id]) }}" class="btn btn-primary btn-sm mr-2"><i class="fa fa-edit"></i></a>
                        <a href="{{ route('fe.hapus_kpi_detail',[$id,$kpi_detail->t_kpi_detail_id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-trash"></i></a>
                        	</div>
                        	@endif
                        </td>
                    </tr>
                    <?php $total_tw1 +=$bobot1;?>
                    <?php $total_tw2 +=$bobot2;?>
                    <?php $total_tw3 +=$bobot3;?>
                    <?php $total_tw4 +=$bobot4;?>
                   
 					@endforeach
 					
 					<tr>
 						<td colspan="10"></td>
 						<td ><?=round($total_tw1)?>%</td>
 						<td colspan="2"></td>
 						<td ><?=round($total_tw2)?>%</td>
 						<td colspan="2"></td>
 						<td ><?=round($total_tw3)?>%</td>
 						<td colspan="2"></td>
 						<td ><?=round($total_tw4)?>%</td>
 						<td ></td>
 					</tr>
                    @endif
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <!-- /.card -->
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection
@extends('layouts.app_fe')

@section('content')
	<div class="row">
	<div class="col-xl-3 col-lg-4 col-md-12 theiaStickySidebar">
		<?= view('layouts.app_side'); ?>
	</div>
	<div class="col-xl-9 col-lg-8 col-md-12">

    <!-- Content Wrapper. Contains page content -->
    <div class="content">
    @include('flash-message')
    <!-- Content Header (Page header) -->
        <div class="card shadow-sm ctm-border-radius">
<div class="card-body align-center">
<h4 class="card-title float-left mb-0 mt-2">Tambah Pengajuan Cuti</h4>

</div>
</div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="card">
            
            <!-- /.card-header -->
            <div class="card-body">
            <?php 
            if(($kar[0]->periode_gajian==1)  ){
				
			
            ?>
                <!-- form start -->
                <form class="form-horizontal" method="POST" action="{!! route('fe.simpan_cuti') !!}" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" class="form-control" placeholder="Nik ..." id="nik" name="nik" value="{!! $kar[0]->nik !!}" readonly>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control" placeholder="Nama ..." id="nama" name="nama" value="{!! $kar[0]->nama_lengkap !!}" readonly>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Jabatan</label>
                                <input type="text" class="form-control" placeholder="Nama Jabatan ..." id="jabatan" name="jabatan" value="{!! $kar[0]->jabatan !!}" readonly>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Departemen</label>
                                <input type="text" class="form-control" placeholder="Nama Departemen..." id="departemen" name="departemen" value="{!! $kar[0]->departemen !!}" readonly>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Tanggal Pengajuan</label>
                                <input type="text" class="form-control" id="tgl_pengajuan" name="tgl_pengajuan" value="{!! date('d-m-Y') !!}" readonly>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Jenis Cuti*</label>
                                <select class="form-control select2" name="cuti" style="width: 100%;" required>
                                    <option value="">Pilih Cuti</option>
                                    <?php
                                    foreach($jeniscuti AS $jeniscuti){
                                    	if($jeniscuti->nama=='CUTI TAHUNAN')
                                    		$jeniscuti->satuan =$totalcuti;
                                        echo '<option value="'.$jeniscuti->m_jenis_ijin_id.'">'.$jeniscuti->nama.' ('.$jeniscuti->satuan.' Hari)'.'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Tanggal Awal*</label>
                                <div class="input-group date" id="tgl_awal" data-target-input="nearest">
                                    <input type="date" class="form-control" id="tgl_awaldate" name="tgl_awal" data-target="#tgl_awal" value="" required onchange="countdate()" min="<?=$help->tambah_tanggal(date('Y-m-d'),1);?>">
                                    
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Tanggal Akhir*</label>
                                <div class="input-group date" id="tgl_akhir" data-target-input="nearest">
                                    <input type="date" class="form-control " id="tgl_akhirdate" name="tgl_akhir" data-target="#tgl_akhir" value="" required onchange="countdate()" min="<?=$help->tambah_tanggal(date('Y-m-d'),1);?>">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Lama (Hari)*</label>
                                <input type="text" class="form-control masking0" id="lama" name="lama" value="" placeholder="Lama Cuti/Izin..." required readonly="">
                            </div>
                        </div>
                        <div class="col-sm-3">
                           
                            <div class="form-group">
                                <label>File</label>
                                <input type="file" class="form-control" id="file" name="file" value="" >
                            </div>
                        </div>
                        <?php if($idkar[0]->m_pangkat_id!=6){?>
                        <div class="col-sm-4">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Penanggung Jawab Sementara *</label>
                                <select class="form-control select2" name="pjs" style="width: 100%;" required="">
                                    <option value="">Pilih Penanggung jawab sementara</option>
                                    <?php
                                  
                                    foreach($karyawan AS $karyawan){
                                       echo '<option value="'.$karyawan->p_karyawan_id.'">'.$karyawan->nama_lengkap.'('.$karyawan->jabatan.')</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Atasan*</label>
                                <select class="form-control select2" name="atasan" style="width: 100%;" required>
                                    <option value="">Pilih Atasan</option>
                                    <?php
                                    foreach($appr AS $appr){
                                        echo '<option value="'.$appr->p_karyawan_id.'">'.$appr->nama_lengkap.'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <?php }?>
                        <div class="col-sm-<?=($idkar[0]->m_pangkat_id!=6)?'12':'6';?>">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Alasan Cuti*</label>
                                <textarea class="form-control" placeholder="Alasan Cuti..." id="alasan" name="alasan"  required=""></textarea>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <a href="{!! route('fe.list_cuti') !!}" class="btn btn-default pull-left"><span class="fa fa-times"></span> Kembali</a>
                        <button type="submit" class="pull-right btn btn-theme button-1 text-white ctm-border-radius p-2 add-person ctm-btn-padding"><span class="fa fa-check"></span> Simpan</button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            <?php }else{?>
				<div class="card-body">
					<h3>Maaf, Untuk Karyawan Pekanan tidak bisa mengajukan Cuti</h3>
				</div>
			<?php }?>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.content -->
    </div><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script>
    	function countdate()
		{
			if( $("#tgl_akhirdate").val() &&  $("#tgl_awaldate").val()){
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				url : "{!! route('fe.hitung_hari') !!}", 
				data : {'tgl_awal' : $("#tgl_awaldate").val(),'tgl_akhir' : $("#tgl_akhirdate").val()},
				type : 'get',
				dataType : 'json',
				success : function(result){
						$('#lama').val(result.count);
						//console.log("===== " + result + " =====");
					
				}
				
			});
	
	 		}
	 	}
    </script>
    <!-- /.content-wrapper -->
@endsection

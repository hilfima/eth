
											<aside class="sidebar sidebar-user">
							
							 

							
							<div class="quicklink-sidebar-menu ctm-border-radius shadow-sm bg-white card">
								<div class="card-body">
									<ul class="list-group">
										<li class="list-group-item text-center button-5"><a href="#" class="text-white">Pengajuan Penambahan BPJS</a></li>
										<li class="list-group-item text-center button-6"><a href="http://localhost/_kerja/es-hcms/public/frontend/status_persetujuan" class="text-dark">Keluarga Cover</a></li>
										<li class="list-group-item text-center button-6"><a href="http://localhost/_kerja/es-hcms/public/frontend/chat_list" class="text-dark">Histori Saldo BPJS</a></li>
									</ul>
								</div>
							</div>
						</aside>
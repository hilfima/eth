<?php

namespace App\Http\Controllers;

use App\User;
use App\Helper_function;
use Illuminate\Http\Request;
use DB;
use Auth;
use Hash;

class HomeController extends Controller
{
    /*
     *
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function form_biodata_kandidat(Request $request)
    {
        return view('form_biodata_kandidat',compact('request'));
    }
    public function undermaintenance()
    {
    	
        return view('undermaintenance');
    }
    public function index()
    {
        $all = array();
        $help = new Helper_function();
        $iduser = Auth::user()->id;
        $sqluser = "SELECT p_recruitment.foto,role FROM users
        
left join m_role on m_role.m_role_id=users.role
left join p_karyawan on p_karyawan.user_id=users.id
left join p_recruitment on p_recruitment.p_recruitment_id=p_karyawan.p_recruitment_id
where users.id=$iduser";

        $user = DB::connection()->select($sqluser);
        //print_r($user);die;
        if ($user[0]->role == -1) {
        } else if ($user[0]->role != 2) {
            return redirect()->route('admin');
        }
        if ($user[0]->foto == null) {
            //echo 'masuk';die;
            $foto = 'user.png';
        } else {
            //echo 'masuk212';die;
            $foto = $user[0]->foto;
        }
		
        $sqlidkar = "select *,p_karyawan.p_karyawan_id as karyawan_id from p_karyawan 
        			left join p_karyawan_pekerjaan a on a.p_karyawan_id = p_karyawan.p_karyawan_id 
        			left join p_karyawan_kontrak on p_karyawan_kontrak.p_karyawan_id = p_karyawan.p_karyawan_id
        			left join p_karyawan_gapok on p_karyawan_gapok.p_karyawan_id = p_karyawan.p_karyawan_id and p_karyawan_gapok.active=1
        			where user_id=$iduser";
        $idkar = DB::connection()->select($sqlidkar);
        $karyawan = $idkar[0];
        $him = $idkar[0]->karyawan_id;
        $id = $idkar[0]->karyawan_id;
        //echo print_r($idkar);die;
        $sqlfasilitas = "SELECT * FROM p_karyawan_faskes
                WHERE 1=1 and active=1 and p_karyawan_id = $id ";
        $fasilitas = DB::connection()->select($sqlfasilitas);

        if (!count($fasilitas)) {
            HomeController::generate_faskes($id);
            $sqlfasilitas = "SELECT * FROM p_karyawan_faskes
                WHERE 1=1 and active=1 and p_karyawan_id = $id ";
            $fasilitas = DB::connection()->select($sqlfasilitas);
        } else {
            HomeController::generate_update_faskes();
            
            if($help->hitungBulan($idkar[0]->tgl_bergabung,date('Y-m-d'))>3){
            	$tahun_date = date('Y');
            	$count = DB::connection()->select("select count(*) from t_faskes where jenis = 1 and tanggal_pengajuan >='$tahun_date-01-01'  and tanggal_pengajuan <='$tahun_date-12-31' and p_karyawan_id = $id ");
            	if(!$count[0]->count){
            		
            	if ($karyawan->periode_gajian == 1) {
	                $gapok = $karyawan->gapok;
	                $grade = $karyawan->tunjangan_grade;
	                $nominal = $gapok + $grade;
	            } else {
	            	 $nominal =  $karyawan->upah_harian * 22;
	            }
            	$generate_check = ($tahun_date+1).'-01-01';
				DB::connection()->table("m_faskes")
                ->where('p_karyawan_id', $id)
                ->update([
                    "tanggal" => ("$tahun_date-01-01"),
                    "generate_add_date" => ($generate_check),
                ]);
				
	            DB::connection()->table("t_faskes")
	                ->insert([ 
	                   
	                    "p_karyawan_id" => ($karyawan->p_karyawan_id),
	                    "nominal" => ($nominal),
	                    "keterangan" => 'Reset Plafon',
	                    "tanggal_pengajuan" => ("$tahun_date-01-01"),
	                    "jenis" => (1),
	                    "appr_status" => (1),
	                    "create_date" => date('Y-m-d'),
	                    "create_by" => $iduser,
	                ]);
	                
	            $sqlfasilitas = "SELECT * FROM p_karyawan_faskes
		                WHERE 1=1 and p_karyawan_id =" . $karyawan->p_karyawan_id;
	            $count = DB::connection()->select($sqlfasilitas);
	            if (count($count)) {

	                $saldo = $nominal;
	                DB::connection()->table("p_karyawan_faskes")
	                    ->where('p_karyawan_faskes_id', $count[0]->p_karyawan_faskes_id)
	                    ->update([
	                        "saldo" => ($saldo),

	                    ]);
	            } else {
	                $saldo = $nominal;
	                DB::connection()->table("p_karyawan_faskes")
	                    ->insert([
	                        "p_karyawan_id" => ($karyawan->p_karyawan_id),
	                        "saldo" => ($saldo)
	                    ]);
	            }
			}
            	}
        }

        $sqlfasilitas = "SELECT * FROM m_cuti
                WHERE 1=1 and active=1 and p_karyawan_id = $id ";
        $cuti = DB::connection()->select($sqlfasilitas);

        if (!count($cuti)) {
            
            HomeController::generate_cuti();
            $sqlfasilitas = "SELECT * FROM m_cuti
                WHERE 1=1 and active=1 and p_karyawan_id = $id ";
            $cuti = DB::connection()->select($sqlfasilitas);
        } else {
            if ($cuti[0]->tgl_generete_add <= date('Y-m-d')) {
                $date_awal = $cuti[0]->tgl_generete_add;

                $bulan_date = explode('-', ($date_awal))[1];
                $nominal = 13 - $bulan_date;

                $tahun_date = explode('-', ($date_awal))[0];
                $date = ($tahun_date + 1) . '-1-1';

                DB::connection()->table("t_cuti")
                    ->insert([
                        "p_karyawan_id" => ($id),
                        "nominal" => ($nominal),
                        "keterangan" => 'Penambahan Cuti Tahun ' . $tahun_date,
                        "tanggal" => ($date_awal),
                        "jenis" => 1,
                        "tgl_reset" => $date,
                        "tahun" => $tahun_date,

                        "create_date" => date('Y-m-d'),
                        "create_by" => $iduser,
                    ]);


                DB::connection()->table("m_cuti")
                    ->where('m_cuti_id', $cuti[0]->m_cuti_id)
                    ->update([
                        "tgl_generete_add" => ($date),
                    ]);
            }else
			
			if($help->hitungBulan($idkar[0]->tgl_bergabung,date('Y-m-d'))>13){
				$c = DB::connection()->select("select count(*) from t_cuti where p_karyawan_id = $id and jenis=1 and tahun = '".date('Y')."'");
				if(!$c[0]->count){
					//ini teh perlu di close cek kalau misal ga ada database terus masuk kesini, otomatis, dia nambah 12 bukan 
					$nominal=12;
					
					$tahun_date = date('Y');
					$date_awal = date('Y-m-d');
					$date = ($tahun_date+1).'-1-1';
					DB::connection()->table("t_cuti")
                    ->insert([
                        "p_karyawan_id" => ($id),
                        "nominal" => ($nominal),
                        "keterangan" => 'Penambahan Cuti Tahun ' . $tahun_date,
                        "tanggal" => ($date_awal),
                        "jenis" => 1,
                        "tgl_reset" => $date,
                        "tahun" => $tahun_date,

                        "create_date" => date('Y-m-d'),
                        "create_by" => $iduser,
                    ]);


                DB::connection()->table("m_cuti")
                    ->where('m_cuti_id', $cuti[0]->m_cuti_id)
                    ->update([
                        "tgl_generete_add" => ($date),
                    ]);
				}
			}
			
            if ($cuti[0]->tgl_generete_add_besar <= date('Y-m-d')) {
                $date_awal = $cuti[0]->tgl_generete_add_besar;
                $date = $help->tambah_bulan($date_awal, (12 * 5));
                $nominal = 10;
                $data = DB::connection()->select("select max(tahun) from t_cuti where jenis=3 and p_karyawan_id = $id");
                $tahun_date = ($data[0]->max) + 1;
                DB::connection()->table("t_cuti")
                    ->insert([
                        "p_karyawan_id" => ($id),
                        "nominal" => ($nominal),
                        "keterangan" => 'Penambahan Cuti Besar ke-' . $tahun_date,
                        "tanggal" => ($date_awal),
                        "jenis" => 3,
                        "tgl_reset" => $date,
                        "tahun" => $tahun_date,

                        "create_date" => date('Y-m-d'),
                        "create_by" => $iduser,
                    ]);


                DB::connection()->table("m_cuti")
                    ->where('m_cuti_id', $cuti[0]->m_cuti_id)
                    ->update([
                        "tgl_generete_add_besar" => ($date),
                    ]);
            }
        }

		$sql="select * from m_periode_absen where type= ".$idkar[0]->periode_gajian." and periode_aktif=1  and tgl_akhir >= '".date('Y-m-d')."' ";
			$gapen=DB::connection()->select($sql);
			if(!count($gapen)){
					$data = array();
					$tgl_awal_gaji = null;
					$tgl_akhir_gaji = null;
					$tgl_akhir_gaji2 = null;
					$tgl_awal_gaji2 = null;
					$tgl_awal_cut_off = null;
			}else{
				
			
			
			
			
					$tgl_awal_gaji = $gapen[0]->tgl_awal;
					
					$tgl_akhir_gaji = $gapen[0]->tgl_akhir;;
					$tgl_awal_gaji2 = $help->tambah_tanggal($tgl_awal_gaji,3);
					$tgl_akhir_gaji2 = $help->tambah_tanggal($tgl_akhir_gaji,3);
					$tgl_awal_cut_off  = $tgl_awal_gaji;
				



				$tgl_akhir_cut_off  = $tgl_akhir_gaji;
				$tgl_cut_off ='';
				if ($tgl_awal_cut_off<=date('Y-m-d') and $tgl_akhir_cut_off>=date('Y-m-d'))
					$tgl_cut_off = $tgl_awal_cut_off;
				else
					$tgl_cut_off = $help->tambah_tanggal($tgl_awal_gaji,1);

		

        //echo $tgl_akhir_gaji;die;

        $tgl_awal = $tgl_awal_gaji;
        $tgl_akhir = date('Y-m-d');
        $sqlusers = "SELECT c.periode_gajian FROM p_karyawan_pekerjaan c
                WHERE 1=1 and c.active=1 and p_karyawan_id=$id";
        $search_type = DB::connection()->select($sqlusers);
        $type = $search_type[0]->periode_gajian;
        $rekap = $help->rekap_absen($tgl_awal, $tgl_akhir, $tgl_awal, $tgl_akhir, $type, null,$id);

        $return = $help->total_rekap_absen($rekap, $id);



        //if($no==5)
        //break;
        $masuk = $return['total']['masuk'];
        $cuti = $return['total']['cuti'];
        $fingerprint = $return['total']['fingerprint'];
        $ipg = $return['total']['ipg'];
        $ihk = $return['total']['izin'];
        $ipd = $return['total']['ipd'];
        $ipc = $return['total']['ipc'];
        $sakit = $return['total']['sakit'];
        $alpha = $return['total']['alpha'];
        $idt = $return['total']['idt'];
        $ipm = $return['total']['ipm'];
        $pm = $return['total']['pm'];
        $terlambat = $return['total']['terlambat'];
        $masuk_libur = $return['total']['masuk_libur'];
        $ijin_libur = $return['total']['ijin_libur'];
        $absen_masuk = $return['total']['Total Absen'];
        $tmasuk = $return['total']['Total Masuk'];
        $hari_kerja = $return['total']['hari_kerja'];

        $data["data"] = array($absen_masuk, $terlambat, $ipd, $ihk, $ipg, $sakit, $cuti, $masuk_libur, $ipc, $ijin_libur, $fingerprint);
        $data["label"] = ['Absen', 'Telambat', 'Perjalanan Dinas', 'IHK', 'IPG', 'Sakit', 'Cuti', 'Masuk  Hari Libur', 'Izin Potong Cuti', 'Masuk Izin Hari Libur', 'IPM', 'PM', 'IDT', 'Belum Absen'];
        $data["sum"] = $absen_masuk + $ipd + $ihk + $ipg + $cuti + $sakit + $ijin_libur + $ipc;
        //echo ($absen_masuk/$hari_kerja*100);die;
        $data["data_presentase"] =
            array((round($absen_masuk / $hari_kerja * 100, 2)),
                (round($terlambat / $hari_kerja * 100, 2)),
                (round($ipd / $hari_kerja * 100, 2)),
                (round($ihk / $hari_kerja * 100, 2)),
                (round($ipg / $hari_kerja * 100, 2)),
                (round($cuti / $hari_kerja * 100, 2)),
                round((($hari_kerja - $data["sum"]) / $hari_kerja) * 100, 2),
                $fingerprint
            );
        $data["data_presentase"] =
            array((round($absen_masuk, 2)),
                (round($terlambat, 2)),
                (round($ipd, 2)),
                (round($ihk, 2)),
                (round($ipg, 2)),
                (round($sakit, 2)),
                (round($cuti, 2)),
                (round($masuk_libur, 2)),
                (round($ipc, 2)),
                (round($ijin_libur, 2)),
                (round($ipm, 2)),
                (round($pm, 2)),
                (round($idt, 2)),
                round($alpha + $fingerprint, 2),


            );
		}
        //	print_r($data);
        $sqlnoabsen = "select * from p_karyawan_absen where p_karyawan_id=$id";
        $datanoabsen = DB::connection()->select($sqlnoabsen);
        $noabsen = $datanoabsen[0]->no_absen;

        /*$sqlstatus="select * from p_karyawan_kontrak where p_karyawan_id=$id";
        $datastatus=DB::connection()->select($sqlstatus);
        $status=$datastatus[0]->m_jenis_pekerjaan_id;*/

        $sqlpa = "select m_jabatan.m_pangkat_id from p_karyawan_pekerjaan 
LEFT JOIN m_jabatan on m_jabatan.m_jabatan_id=p_karyawan_pekerjaan.m_jabatan_id
LEFT JOIN m_pangkat on m_pangkat.m_pangkat_id=m_jabatan.m_pangkat_id
where p_karyawan_id=$id

";
        //echo $sqlpa;die;
        $pa = DB::connection()->select($sqlpa);
        $pangkat = 0;
        if (!empty($pa['m_pangkat_id'][0])) {
            $pangkat = $pa['m_pangkat_id'][0];
        }

        $tgl_awal = date('Y-m-d');
        $tgl_akhir = date('Y-m-d');
        $sqlabsen = "SELECT DISTINCT a.pin,c.nik,c.nama,to_char(a.date_time,'dd-mm-yyyy') as tgl_absen,to_char(a.date_time,'HH24:MI:SS') as jam_masuk,
case when to_char(date_time,'HH24:MI')>'07:30' then 'Terlambat' else 'OK' end as keterangan,f.nama as nmlokasi
FROM absen_log a
LEFT JOIN p_karyawan_absen b on b.no_absen=a.pin
LEFT JOIN p_karyawan c on c.p_karyawan_id=b.p_karyawan_id
LEFT JOIN p_karyawan_pekerjaan d on d.p_karyawan_id=c.p_karyawan_id
LEFT JOIN m_lokasi e on e.m_lokasi_id=d.m_lokasi_id
LEFT JOIN m_mesin_absen f on f.mesin_id=a.mesin_id
WHERE to_char(a.date_time,'yyyy-mm-dd')>='" . $tgl_awal . "' and to_char(a.date_time,'yyyy-mm-dd')<='" . $tgl_akhir . "' and a.ver=1 
and to_char(date_time,'HH24:MI')>'07:30'
ORDER BY nama,to_char(a.date_time,'dd-mm-yyyy'),nmlokasi";
        $absen = DB::connection()->select($sqlabsen);

        $sqlabsenin = "SELECT DISTINCT a.pin,c.nik,c.nama,to_char(a.date_time,'dd-mm-yyyy') as tgl_absen,to_char(a.date_time,'HH24:MI:SS') as jam_masuk,
case when to_char(date_time,'HH24:MI')>'07:30' then 'Terlambat' else 'OK' end as keterangan,f.nama as nmlokasi
FROM absen_log a
LEFT JOIN p_karyawan_absen b on b.no_absen=a.pin
LEFT JOIN p_karyawan c on c.p_karyawan_id=b.p_karyawan_id
LEFT JOIN p_karyawan_pekerjaan d on d.p_karyawan_id=c.p_karyawan_id
LEFT JOIN m_lokasi e on e.m_lokasi_id=d.m_lokasi_id
LEFT JOIN m_mesin_absen f on f.mesin_id=a.mesin_id
WHERE to_char(a.date_time,'yyyy-mm-dd')>='" . $tgl_awal . "' and to_char(a.date_time,'yyyy-mm-dd')<='" . $tgl_akhir . "' and a.ver=1 
and a.pin=$noabsen
ORDER BY nama,to_char(a.date_time,'dd-mm-yyyy'),nmlokasi";
        $absenin = DB::connection()->select($sqlabsenin);

        $sqlabsenout = "SELECT DISTINCT a.pin,c.nik,c.nama,to_char(a.date_time,'dd-mm-yyyy') as tgl_absen,to_char(a.date_time,'HH24:MI:SS') as jam_keluar,f.nama as nmlokasi
FROM absen_log a
LEFT JOIN p_karyawan_absen b on b.no_absen=a.pin
LEFT JOIN p_karyawan c on c.p_karyawan_id=b.p_karyawan_id
LEFT JOIN p_karyawan_pekerjaan d on d.p_karyawan_id=c.p_karyawan_id
LEFT JOIN m_lokasi e on e.m_lokasi_id=d.m_lokasi_id
LEFT JOIN m_mesin_absen f on f.mesin_id=a.mesin_id
WHERE to_char(a.date_time,'yyyy-mm-dd')>='" . $tgl_awal . "' and to_char(a.date_time,'yyyy-mm-dd')<='" . $tgl_akhir . "' and a.ver=2 
and a.pin=$noabsen
ORDER BY nama,to_char(a.date_time,'dd-mm-yyyy'),nmlokasi";
        $absenout = DB::connection()->select($sqlabsenout);


       

        $sqlultah = "SELECT nama_Lengkap,tgl_lahir, EXTRACT(year FROM AGE(now(), tgl_lahir)) as usia FROM p_recruitment 
        			join p_karyawan on p_karyawan.p_recruitment_id = p_recruitment.p_recruitment_id 
                    WHERE to_char(tgl_lahir,'mm') = to_char(now(),'mm') and to_char(tgl_lahir,'dd') = to_char(now(),'dd') and p_karyawan.active=1 ORDER BY to_char(tgl_lahir,'%d %m'),tgl_lahir ";
        $ultah = DB::connection()->select($sqlultah);

        $sql = "SELECT * from m_qoute where tgl_awal<='" . date('Y-m-d') . "' and tgl_akhir>='" . date('Y-m-d') . "' order by  random() ";
        $qoute = DB::connection()->select($sql);

        //$tahun=date('Y');
        //$sqlcuti="SELECT * FROM get_list_cuti_tahunan_new($tahun,$id) ";
        //$cuti=DB::connection()->select($sqlcuti);

        $sqlumurkerja = "SELECT AGE(CURRENT_DATE, p_karyawan.tgl_bergabung)::VARCHAR AS umur FROM p_karyawan where p_karyawan_id=$id";
        $umurkerja = DB::connection()->select($sqlumurkerja);

        $sqldw = "SELECT * FROM get_data_karyawan() WHERE p_karyawan_id=$id";
        $dw = DB::connection()->select($sqldw);


        date_default_timezone_set('Asia/Jakarta');
        $usersave = User::find(Auth::user()->id);
        $usersave->last_login = date('Y-m-d H:i:s');
        $usersave->save();
        $help = new Helper_function();
        $cuti = $help->query_cuti2($idkar);
        $date2 = $cuti['date'];
        $all = $cuti['all'];
        $tanggal_loop = $cuti['tanggal_loop'];


        $id_jabatan = $idkar[0]->m_jabatan_id;
        $id_karyawan = $idkar[0]->p_karyawan_id;
        

        return view('home', compact('id', 'pangkat', 'absen', 'user', 'absenin', 'absenout',  'ultah', 'foto', 'cuti',  'umurkerja', 'dw', 'help', 'data', 'tgl_awal_gaji', 'tgl_akhir_gaji', 'tgl_akhir_gaji2', 'fasilitas', 'cuti', 'data', 'idkar', 'all', 'date2',  'tanggal_loop', 'qoute'));
    }

    public function admin()
    {
        $iduser = Auth::user()->id;
        $sqlidkar = "select * from p_karyawan where user_id=$iduser";
        $idkar = DB::connection()->select($sqlidkar);
        //$id=$idkar[0]->p_karyawan_id;

        $sqljmlkaryawan = "SELECT count(COALESCE(p_karyawan_id,0)) as jmlkaryawan
                    FROM p_karyawan
                    WHERE 1=1 and active=1";
        $jmlkaryawan = DB::connection()->select($sqljmlkaryawan);

        $sqljmldivisi = "SELECT count(COALESCE(m_divisi_id,0)) as jmldivisi
                    FROM m_divisi
                    WHERE 1=1 and active=1";
        $jmldivisi = DB::connection()->select($sqljmldivisi);

        $sqljmllokasi = "SELECT count(COALESCE(m_lokasi_id,0)) as jmllokasi
                    FROM m_lokasi
                    WHERE 1=1 and active=1 and sub_entitas=0";
        $jmllokasi = DB::connection()->select($sqljmllokasi);

        $sqljmldepartemen = "SELECT count(COALESCE(m_departemen_id,0)) as jmldepartemen
                    FROM m_departemen
                    WHERE 1=1 and active=1";
        $jmldepartemen = DB::connection()->select($sqljmldepartemen);

        /*$sqljmllaki = "SELECT count(b.m_jenis_kelamin_id) as laki FROM p_karyawan a
LEFT JOIN p_recruitment b on b.p_recruitment_id=a.p_recruitment_id
WHERE a.active=1 and b.m_jenis_kelamin_id=1";
        $jmllaki = DB::connection()->select($sqljmllaki);

        $sqljmlwanita = "SELECT count(b.m_jenis_kelamin_id) as wanita FROM p_karyawan a
LEFT JOIN p_recruitment b on b.p_recruitment_id=a.p_recruitment_id
WHERE a.active=1 and b.m_jenis_kelamin_id=2";
        $jmlwanita = DB::connection()->select($sqljmlwanita);*/

        $help = new Helper_function();
        $tgl = $help->tambah_bulan(date('Y-m-') . '1', 1);
		/*
        $sqlkontrak = "SELECT p_karyawan_kontrak.*,p_karyawan.nik,p_karyawan.nama,m_divisi.nama as nmdivisi,m_departemen.nama as nmdept 
                    FROM p_karyawan_kontrak
                    LEFT JOIN p_karyawan on p_karyawan.p_karyawan_id=p_karyawan_kontrak.p_karyawan_id
                    LEFT JOIN p_karyawan_pekerjaan on p_karyawan_pekerjaan.p_karyawan_id=p_karyawan.p_karyawan_id
                    LEFT JOIN m_divisi on m_divisi.m_divisi_id=p_karyawan_pekerjaan.m_divisi_id
                    LEFT JOIN m_departemen on m_departemen.m_departemen_id=p_karyawan_pekerjaan.m_departemen_id
                    WHERE 1=1 and p_karyawan_kontrak.active=1 and p_karyawan_kontrak.m_status_pekerjaan_id NOT IN(10) 
                    and p_karyawan_kontrak.tgl_akhir <'" . $tgl . "' and p_karyawan.active=1 ";
        $kontrak = DB::connection()->select($sqlkontrak);*/

        $sqltotalkontrak = "SELECT count(*) as total 
                    FROM p_karyawan_kontrak
                    LEFT JOIN p_karyawan on p_karyawan.p_karyawan_id=p_karyawan_kontrak.p_karyawan_id
                    LEFT JOIN p_karyawan_pekerjaan on p_karyawan_pekerjaan.p_karyawan_id=p_karyawan.p_karyawan_id
                    LEFT JOIN m_divisi on m_divisi.m_divisi_id=p_karyawan_pekerjaan.m_divisi_id
                    LEFT JOIN m_departemen on m_departemen.m_departemen_id=p_karyawan_pekerjaan.m_departemen_id
                    WHERE 1=1 and p_karyawan_kontrak.active=1  and p_karyawan_kontrak.m_status_pekerjaan_id NOT IN(10) 
                    and p_karyawan_kontrak.tgl_akhir <'" . $tgl . "' and p_karyawan.active=1 ";
        $totalkontrak = DB::connection()->select($sqltotalkontrak);

        /*$sqlpa = "select m_jabatan.m_pangkat_id from p_karyawan_pekerjaan 
LEFT JOIN m_jabatan on m_jabatan.m_jabatan_id=p_karyawan_pekerjaan.m_jabatan_id
LEFT JOIN m_pangkat on m_pangkat.m_pangkat_id=m_jabatan.m_pangkat_id
where p_karyawan_id=$iduser";
        //echo $sqlpa;die;
        $pa = DB::connection()->select($sqlpa);
        $pangkat = 0;
        if (!empty($pa['m_pangkat_id'][0])) {
            $pangkat = $pa['m_pangkat_id'][0];
        }

        $sqllokasi = "SELECT * FROM m_lokasi WHERE 1=1 and active=1";
        $lokasi = DB::connection()->select($sqllokasi);
        $jam_masuk = $lokasi[0]->jam_masuk;

        $sqllokasimofas = "SELECT * FROM m_lokasi WHERE 1=1 and m_lokasi_id=6 and active=1";
        $lokasimofas = DB::connection()->select($sqllokasimofas);
        $jam_masukmofas = $lokasimofas[0]->jam_masuk;
        //rekap Absen
        */
		$help = new Helper_function();
        $tgl_awal = (date('Y-m-d'));
        $tgl_akhir = date('Y-m-d');
        
		$rekap = $help->rekap_absen($tgl_awal,$tgl_akhir,$tgl_awal,$tgl_akhir,-1);
		$list_karyawan = $rekap['list_karyawan'] ;
		
		$hari_libur = $rekap['hari_libur'] ;
		$hari_libur_shift = $rekap['hari_libur_shift'] ;
		$tgl_awal_lembur = $rekap['tgl_awal_lembur'] ;
		$tgl_awal = $rekap['tgl_awal'] ;
		$tgl_akhir = $rekap['tgl_akhir'] ;
		
		$sqluser="SELECT p_recruitment.foto,role FROM users
left join p_karyawan on p_karyawan.user_id=users.id
left join p_recruitment on p_recruitment.p_recruitment_id=p_karyawan.p_karyawan_id
where users.id=$iduser";
        $user=DB::connection()->select($sqluser);

 
        // echo print_r($list_karyawan);die;
        return view('admin', compact('jmlkaryawan', 'jmldivisi', 'jmllokasi', 'jmldepartemen',  'totalkontrak',   'rekap', 'list_karyawan',  'help', 'user'));
    }

    public function historis(Request $request)
    {
		$help = new Helper_function();
		DB::enableQueryLog();
		$query = (DB::getQueryLog());
		$help->historis($request->historis_page);
    }public function password()
    {

        return view('password');
    }
    public function simpan_password(Request $request)
    {

        DB::beginTransaction();
        try {
            $iduser = Auth::user()->id;
            $password = $request->get("password");
            if ($password != '' || $password != null) {

                DB::connection()->table("users")
                    ->where("id", $iduser)
                    ->update([
                        "password" => Hash::make($password),
                        "updated_at" => date("Y-m-d"),
                    ]);
                //DB::commit();
            }
            return redirect()->route('password')->with('success', ' Password Berhasil di Ubah!');
        } catch (\Exeception $e) {
            //DB::rollback();
            return redirect()->back()->with('error', $e);
        }
    }

    public function ultah()
    {
        $sqlultah = "SELECT a.nik,a.nama,b.tgl_lahir,d.nama as nmlokasi,e.nama as nmdept,EXTRACT(year FROM AGE(now(), tgl_lahir)) || ' Tahun' as usia 
FROM p_karyawan a
LEFT JOIN p_recruitment b on b.p_recruitment_id=a.p_recruitment_id
LEFT JOIN p_karyawan_pekerjaan c on c.p_karyawan_id=a.p_karyawan_id
LEFT JOIN m_lokasi d on d.m_lokasi_id=c.m_lokasi_id
LEFT JOIN m_departemen e on e.m_departemen_id=c.m_departemen_id
WHERE date_part('month',b.tgl_lahir)=" . date('m');
        $ultah = DB::connection()->select($sqlultah);
        //var_dump($ultah);die;
        return response()->json($ultah);
    }

    public function news()
    {
        $sqlnews = "SELECT * FROM hr_care a WHERE a.active=1";
        $news = DB::connection()->select($sqlnews);

        return response()->json($news);
    }
    public function generate_cuti(){
    	 $help = new Helper_function();
        $iduser = Auth::user()->id;
        $sqluser = "SELECT p_recruitment.foto,role FROM users
        
left join m_role on m_role.m_role_id=users.role
left join p_karyawan on p_karyawan.user_id=users.id
left join p_recruitment on p_recruitment.p_recruitment_id=p_karyawan.p_recruitment_id
where users.id=$iduser";

        $user = DB::connection()->select($sqluser);
        $sqlidkar = "select * from p_karyawan 
        			join p_karyawan_pekerjaan a on a.p_karyawan_id = p_karyawan.p_karyawan_id 
        			join p_karyawan_kontrak on p_karyawan_kontrak.p_karyawan_id = p_karyawan.p_karyawan_id
        			where user_id=$iduser";
        $idkar = DB::connection()->select($sqlidkar);
        $him = $idkar[0]->p_karyawan_id;
        $id = $idkar[0]->p_karyawan_id;
        
        
    	$sqlfasilitas = "SELECT * FROM p_karyawan 
				join p_karyawan_pekerjaan a on a.p_karyawan_id = p_karyawan.p_karyawan_id
				WHERE 1=1 and a.active=1 and p_karyawan.p_karyawan_id=$id ";
            $karyawan = DB::connection()->select($sqlfasilitas);
            $iduser = Auth::user()->id;
            $help = new Helper_function();
            foreach ($karyawan as $karyawan) {
                $date         = $karyawan->tgl_bergabung;
                $dateBesar     = $karyawan->tgl_bergabung;
                $id_karyawan     = $karyawan->p_karyawan_id;
                $x = 1;
                while ($date <= date('Y-m-d')) {
                    if ($x == 1) {
                        $nominal = 0;
                    } else {
                        $nominal = 12;
                    }
                    if ($x == 3) {
                        $tahun_date = explode('-', ($date))[0];
                        $date = $tahun_date . '-1-1';
                    }

                    $generate_check = $help->tambah_bulan($date, 12);

                    $sqlfasilitas = "SELECT * FROM m_cuti
		                WHERE 1=1 and active=1 and p_karyawan_id = $id_karyawan ";
                    $count = DB::connection()->select($sqlfasilitas);


                    if (count($count)) {
                        DB::connection()->table("m_cuti")
                            ->where('m_cuti_id', $count[0]->m_cuti_id)
                            ->update([
                                "tanggal" => ($date),
                                "tgl_generete_add" => ($generate_check),
                            ]);
                    } else {

                        DB::connection()->table("m_cuti")
                            ->insert([

                                "p_karyawan_id" => ($karyawan->p_karyawan_id),
                                "tgl_generete_add" => ($generate_check),
                            ]);
                    }
                    //dia akan direset kalau setelah desember adalah tanggal tahun
                    //jenis 1 adalah penambahan plafon tahunan
                    // jenis 2 adalah reset plafon
                    $ex_date = explode('-', $date);
                    $ex_generate_check = explode('-', $generate_check);
                    $tgl_reset = $ex_generate_check[0] . '-12-31';
                    DB::connection()->table("t_cuti")
                        ->insert([
                            "p_karyawan_id" => ($karyawan->p_karyawan_id),
                            "nominal" => ($nominal),
                            "keterangan" => $x == 1 ? 'Karyawan Bergabung ke Perusahaan' : 'Penambahan Cuti Tahun ' . $ex_date[0],
                            "tanggal" => ($date),
                            "jenis" => $x == 1 ? 0 : (1),
                            "tgl_reset" => $x == 1 ? null : $tgl_reset,
                            "tahun" => $x == 1 ? null : $ex_date[0],

                            "create_date" => date('Y-m-d'),
                            "create_by" => $iduser,
                        ]);
                    if ($x != 1) {

                        DB::connection()->table("t_cuti")
                            ->insert([
                                "p_karyawan_id" => ($karyawan->p_karyawan_id),
                                "nominal" => ($nominal),
                                "keterangan" => $x == 1 ? 'Karyawan Bergabung ke Perusahaan' : 'Reset Cuti Tahunan ' . $ex_date[0],
                                "tanggal" => ($tgl_reset),
                                "jenis" => $x == 1 ? 0 : (2),
                                "tgl_reset" => $x == 1 ? null : $tgl_reset,
                                "tahun" => $x == 1 ? null : $ex_date[0],

                                "create_date" => date('Y-m-d'),
                                "create_by" => $iduser,
                            ]);
                    }




                    $x++;
                    $date = $generate_check;
                }

                $date = $help->tambah_tanggal($dateBesar, 1);
                $x = 1;
                while ($date < date('Y-m-d')) {
                    if ($x == 1) {
                        $nominal = 0;
                    } else {
                        $nominal = 10;
                    }
                    $generate_check = $help->tambah_bulan($date, 12 * 5);
                    $sqlfasilitas = "SELECT * FROM m_cuti
		                WHERE 1=1 and active=1 and p_karyawan_id = $id_karyawan ";
                    $count = DB::connection()->select($sqlfasilitas);


                    if (count($count)) {
                        DB::connection()->table("m_cuti")
                            ->where('m_cuti_id', $count[0]->m_cuti_id)
                            ->update([
                                "tanggal" => ($date),
                                "tgl_generete_add_besar" => ($generate_check),
                            ]);
                    } else {

                        DB::connection()->table("m_cuti")
                            ->insert([

                                "p_karyawan_id" => ($karyawan->p_karyawan_id),
                                "tgl_generete_add_besar" => ($generate_check),
                            ]);
                    }
                    //dia akan direset kalau setelah desember adalah tanggal tahun
                    //jenis 1 adalah penambahan plafon tahunan
                    // jenis 2 adalah reset plafon
                    $ex_date = explode('-', $date);
                    $tgl_reset = $generate_check;
                    if ($x != 1) {
                        $ke = $x - 1;
                        DB::connection()->table("t_cuti")
                            ->insert([
                                "p_karyawan_id" => ($karyawan->p_karyawan_id),
                                "nominal" => ($nominal),
                                "keterangan" => 'Penambahan Cuti Besar ke-' . $ke,
                                "tanggal" => ($date),
                                "jenis" => $x == 1 ? 0 : (3),
                                "tgl_reset" => $x == 1 ? null : $tgl_reset,
                                "tahun" => $x == 1 ? null : $ke,

                                "create_date" => date('Y-m-d'),
                                "create_by" => $iduser,
                            ]);
                        DB::connection()->table("t_cuti")
                            ->insert([
                                "p_karyawan_id" => ($karyawan->p_karyawan_id),
                                "nominal" => ($nominal),
                                "keterangan" => 'Reset Cuti Besar ke-' . $ke,
                                "tanggal" => ($tgl_reset),
                                "jenis" => $x == 1 ? 0 : (4),
                                "tgl_reset" => $x == 1 ? null : $tgl_reset,
                                "tahun" => $x == 1 ? null : $ke,

                                "create_date" => date('Y-m-d'),
                                "create_by" => $iduser,
                            ]);
                    }




                    $x++;
                    $date = $generate_check;
                }
            }
    }
    public function generate_update_faskes($id_karyawan = null)
    {
        $iduser = Auth::user()->id;
        $help = new Helper_function();
        $date = date('Y-m-d');
        
        $sqlfasilitas = "SELECT *
    					
    					FROM m_faskes
    					Join p_karyawan on m_faskes.p_karyawan_id  = p_karyawan.p_karyawan_id and p_karyawan.active=1
    					join p_karyawan_pekerjaan a on a.p_karyawan_id = p_karyawan.p_karyawan_id
						join p_karyawan_gapok b on b.p_karyawan_id = p_karyawan.p_karyawan_id and b.active=1
                
		                WHERE 1=1 and m_faskes.active=1 and generate_add_date<='$date'";
        $faskes = DB::connection()->select($sqlfasilitas);
        foreach ($faskes as $karyawan) {
           
            $date = $karyawan->tanggal;
            if ($karyawan->periode_gajian == 1) {
                $gapok = $karyawan->gapok;
                $grade = $karyawan->tunjangan_grade;
                $nominal = $gapok + $grade;
            } else {
            	 $nominal =  $karyawan->upah_harian * 22;
            }
            $generate_check = $help->tambah_bulan($date, 12);
            DB::connection()->table("m_faskes")
                ->where('m_faskes_id', $karyawan->m_faskes_id)
                ->update([
                    "tanggal" => (date('Y-m-d')),
                    "generate_add_date" => ($generate_check),
                ]);

            DB::connection()->table("t_faskes")
                ->insert([
                    "p_karyawan_id" => ($karyawan->p_karyawan_id),
                    "nominal" => ($nominal),
                    "keterangan" => 'Reset Plafon',
                    "tanggal_pengajuan" => (date('Y-m-d')),
                    "jenis" => (1),
                    "appr_status" => (1),
                    "create_date" => date('Y-m-d'),
                    "create_by" => $iduser,
                ]);
            $sqlfasilitas = "SELECT * FROM p_karyawan_faskes
		                WHERE 1=1 and p_karyawan_id =" . $karyawan->p_karyawan_id;
            $count = DB::connection()->select($sqlfasilitas);
            if (count($count)) {

                $saldo =  $nominal;
                DB::connection()->table("p_karyawan_faskes")
                    ->where('p_karyawan_faskes_id', $count[0]->p_karyawan_faskes_id)
                    ->update([
                        "saldo" => ($saldo),

                    ]);
            } else {
                $saldo = $nominal;
                DB::connection()->table("p_karyawan_faskes")
                    ->insert([
                        "p_karyawan_id" => ($karyawan->p_karyawan_id),
                        "saldo" => ($saldo)
                    ]);
            }
        }
    }
    public function generate_faskes($id_karyawan = null)
    {
        $where = '';
        if (!$id_karyawan) {
            DB::connection()->table("m_faskes")->delete();
            DB::connection()->table("t_faskes")->delete();
            DB::connection()->table("p_karyawan_faskes")->delete();
        } else {
            $where = ' and p_karyawan.p_karyawan_id=' . $id_karyawan;
        }
        $iduser = Auth::user()->id;
        $help = new Helper_function();
        $sqlfasilitas = "SELECT * FROM p_karyawan 
				join p_karyawan_pekerjaan a on a.p_karyawan_id = p_karyawan.p_karyawan_id
				join p_karyawan_gapok b on b.p_karyawan_id = p_karyawan.p_karyawan_id and b.active=1
                WHERE 1=1 and a.active=1 $where";
        $karyawan = DB::connection()->select($sqlfasilitas);
        foreach ($karyawan as $karyawan) {
            $date = $karyawan->tgl_bergabung;
            $x = 1;

            if ($karyawan->periode_gajian == 1) {
                $gapok = $karyawan->gapok;
                $grade = $karyawan->tunjangan_grade;
                $nominala = $gapok + $grade;
            } else {

                $nominala =  $karyawan->upah_harian * 22;
            }

            while ($date < date('Y-m-d')) {
                if ($x == 1) {
                    $nominal = 0;
                } else {
                    $nominal = $nominala;
                }
                $id_karyawan = $karyawan->p_karyawan_id;
                $sqlfasilitas = "SELECT * FROM m_faskes
		                WHERE 1=1 and active=1 and p_karyawan_id = $id_karyawan ";
                $count = DB::connection()->select($sqlfasilitas);
                if ($x == 1)
                    $generate_check = $help->tambah_bulan($date, 3);
                else
                    $generate_check = $help->tambah_bulan($date, 12);
                if (count($count)) {
                    DB::connection()->table("m_faskes")
                        ->where('m_faskes_id', $count[0]->m_faskes_id)
                        ->update([
                            "tanggal" => ($date),
                            "generate_add_date" => ($generate_check),
                        ]);
                } else {

                    DB::connection()->table("m_faskes")
                        ->insert([

                            "p_karyawan_id" => ($karyawan->p_karyawan_id),
                            "tanggal" => ($date),
                            "generate_add_date" => ($generate_check),
                        ]);
                }
                
                DB::connection()->table("t_faskes")
                    ->insert([
                        "p_karyawan_id" => ($karyawan->p_karyawan_id),
                        "nominal" => ($nominal),
                        "keterangan" => $x == 1 ? 'Karyawan Bergabung ke Perusahaan' : 'Penambahan Plafon',
                        "tanggal_pengajuan" => ($date),
                        "jenis" => (1),
                        "appr_status" => (1),
                        "create_date" => date('Y-m-d'),
                        "create_by" => $iduser,
                    ]);
                $sqlfasilitas = "SELECT * FROM p_karyawan_faskes
		                WHERE 1=1 and p_karyawan_id = $id_karyawan ";
                $count = DB::connection()->select($sqlfasilitas);
                if (count($count)) {

                    $saldo = $count[0]->saldo + $nominal;
                    DB::connection()->table("p_karyawan_faskes")
                        ->where('p_karyawan_faskes_id', $count[0]->p_karyawan_faskes_id)
                        ->update([
                            "saldo" => ($saldo),

                        ]);
                } else {
                    $saldo = $nominal;
                    DB::connection()->table("p_karyawan_faskes")
                        ->insert([
                            "p_karyawan_id" => ($karyawan->p_karyawan_id),
                            "saldo" => ($saldo)
                        ]);
                }
                $x++;
                $date = $generate_check;
            }
        }
    }
}

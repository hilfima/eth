<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Auth;

class AdminController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function admin()
    {
       
        $sqladmin="SELECT m_role.nama_role,m_role_id from m_role
       
                WHERE 1=1 and active = 1 ";
        $Admin=DB::connection()->select($sqladmin);
        
        $sql="SELECT * from m_lokasi
       
                WHERE 1=1  and active = 1 ";
        $lokasi=DB::connection()->select($sqladmin);
        return view('backend.admin.admin',compact('Admin','lokasi')); 
    }

	
    public function lihat($id)
    {
    	
        $sqlrole="SELECT m_role.nama_role,m_role_id,user_entitas_access from m_role
       
                WHERE 1=1  and m_role_id = $id";
        $role=DB::connection()->select($sqlrole);
        $sqladmin="SELECT * from users_admin
                WHERE 1=1  and m_role_id = $id";
        $Admin=DB::connection()->select($sqladmin);
         $sql="SELECT * from m_lokasi
       
                WHERE 1=1  and active = 1 ";
        $lokasi=DB::connection()->select($sql); 
        $selectMenu = array();
         $selectMenu['checked']= array();
        foreach($Admin as $menu){
			$selectMenu['checked'][] = $menu->menu_id;
		}
		$selectMenu['disable'] = 'disabled';
		 
    	 return view('backend.admin.edit',compact('selectMenu','role','id','lokasi'));
    } public function edit_admin($id)
    {
    	 $sql="SELECT * from m_lokasi
       
                WHERE 1=1  and active = 1 ";
        $lokasi=DB::connection()->select($sql); 
        $sqlrole="SELECT m_role.nama_role,m_role_id,user_entitas_access from m_role
       
                WHERE 1=1  and m_role_id = $id";
        $role=DB::connection()->select($sqlrole);
        $sqladmin="SELECT * from users_admin
       
                WHERE 1=1  and m_role_id = $id";
        $Admin=DB::connection()->select($sqladmin);
        $selectMenu = array();
        $selectMenu['checked']= array();
        foreach($Admin as $menu){
			$selectMenu['checked'][] = $menu->menu_id;
		}
		$selectMenu['disable'] = '';
    	 return view('backend.admin.edit',compact('selectMenu','role','id','lokasi'));
    }

    public function tambah_admin()
    {
         $sql="SELECT * from m_lokasi
       
                WHERE 1=1  and active = 1 ";
        $lokasi=DB::connection()->select($sql); 
 		$sqluser="SELECT * from m_role
                WHERE 1=1 and  active = 1 ";
 		$users=DB::connection()->select($sqluser);
        return view('backend.admin.tambah_admin',compact('users','lokasi'));
    }

    public function hapus_admin($id){
    	 DB::connection()->table("m_role")
                ->where("m_role_id",$id)
                ->update([
                "active" =>0,
               
                
            ]);
         DB::connection()->table("users_admin")
                ->where("m_role_id",$id)
               ->update([
                "active" =>0,
            ]);
    	return redirect()->route('be.admin')->with('success',' admin Berhasil di Hapus!');
    }

    public function simpan_admin(Request $request){
    	
	  // echo $kode;die;
       $sqluser="SELECT count(*) as count from m_role";
 		$users=DB::connection()->select($sqluser);
 		$id =$users[0]->count+1; 
 		 DB::connection()->table("m_role")
            ->insert([
                "m_role_id" =>$id,
                "nama_role" => $request->get("user"),
                "user_entitas_access" => $request->get("entitas")
                
            ]);
            
             $menu = $request->get("menu");
         DB::connection()->table("users_admin")
                ->where("m_role_id",$id)
                ->delete();
                if($menu){
					
       for($i=0;$i<count($menu);$i++){
	   	
        $idUser=Auth::user()->id;
        DB::connection()->table("users_admin")
            ->insert([
                "m_role_id" =>$id,
                "menu_id" => $menu[$i],
                
            ]);
	   }
	   $menu = $request->get("parent");
	   for($i=0;$i<count($menu);$i++){
	   	
        $idUser=Auth::user()->id;
        DB::connection()->table("users_admin")
            ->insert([
                "m_role_id" => $id,
                "menu_id" => $menu[$i],
                
            ]);
	   }
				}

        return redirect()->route('be.admin')->with('success',' admin Berhasil di input!');
    }public function update_admin(Request $request,$id){
    	
	  // echo $kode;die;
        DB::beginTransaction();
        try{
 		DB::connection()->table("m_role")
                ->where("m_role_id",$id)
                ->update([
                	"nama_role" => $request->get("user"),
                	"user_entitas_access" => $request->get("entitas")
            ]);
            
             $menu = $request->get("menu");
         DB::connection()->table("users_admin")
                ->where("m_role_id",$id)
                ->delete();
       for($i=0;$i<count($menu);$i++){
	   	
        $idUser=Auth::user()->id;
        DB::connection()->table("users_admin")
            ->insert([
                "m_role_id" =>$id,
                "menu_id" => $menu[$i],
                
            ]);
	   }
	   $menu = $request->get("parent");
	   for($i=0;$i<count($menu);$i++){
	   	
        $idUser=Auth::user()->id;
        DB::connection()->table("users_admin")
            ->insert([
                "m_role_id" => $id,
                "menu_id" => $menu[$i],
                
            ]);
	   }
		DB::commit();
            
        }
        catch(\Exeception $e){
            DB::rollback();
            return redirect()->back()->with('error',$e);
        }

        return redirect()->route('be.admin')->with('success',' admin Berhasil di input!');
    }

    
}
